const express = require("express");

const router = express.Router();
const pool = require("../config");

// Get comment
router.get('/:blogId/comments', function(req, res, next){

});

// Create new comment
router.post('/:blogId/comments', async function(req, res, next){
    try{
     const [rows, fields] = await pool.query("INSERT INTO comments(blog_id,comment,comments.like) VALUES(?,?,?)", [
      req.params.blogId,'Hey',0,
    ]);
      console.log('Selected comments =', rows)
        // let comments = rows.coments
   
    }catch (err) {
        return next(err);
      }
    
});

// Update comment
router.put('/comments/:commentId', async function(req, res, next){
    try{
        const [rows, fields] = await pool.query("INSERT INTO comments(blog_id,comment,comments.like) VALUES(?,?,?)", [
         req.params.blogId,'Hey',0,
       ]);
         console.log('Selected comments =', rows)
           // let comments = rows.coments
      
       }catch (err) {
           return next(err);
         }
       
});

// Delete comment
router.delete('/comments/:commentId', function(req, res, next){
    return
});

// Delete comment
router.put('/comments/addlike/:commentId', function(req, res, next){
    return
});


exports.router = router